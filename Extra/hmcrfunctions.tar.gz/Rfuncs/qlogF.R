qlogF <-
function(x){log(.2*((1-x)^(-5) - 1))}
