dlogF <-
function(x){exp(x)/(1+5*exp(x))^(1.2)}
