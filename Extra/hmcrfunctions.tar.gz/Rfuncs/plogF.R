plogF <-
function(x){1- (1+5*exp(x))^(-.2)}
